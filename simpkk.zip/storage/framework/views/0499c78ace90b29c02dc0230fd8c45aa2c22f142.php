<img src="<?php echo e(asset('images/logoPKK.jpg')); ?>" alt="logo" class="h-full shadow-sm">
<?php /**PATH C:\applications\simpkk\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
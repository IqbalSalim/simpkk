<div x-cloak class="px-4 py-2 bg-white rounded-lg shadow-lg" x-data="{ modal: false, modalEdit: false }"
    x-on:close-modal.window="modal = false" x-on:close-modal-edit.window="modalEdit = false">
    <div class="flex flex-row items-center justify-between py-2 font-semibold text-gray-700 border-b-2 border-gray-300">
        <div>
            <h2>Daftar User</h2>
        </div>
        <div>
            <button class="btn-primary" @click="modal = true">Tambah User</button>

        </div>
    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create-user', [])->html();
} elseif ($_instance->childHasBeenRendered('l1014012733-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1014012733-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1014012733-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1014012733-0');
} else {
    $response = \Livewire\Livewire::mount('user.create-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1014012733-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:user.create-user>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.edit-user', [])->html();
} elseif ($_instance->childHasBeenRendered('l1014012733-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1014012733-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1014012733-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1014012733-1');
} else {
    $response = \Livewire\Livewire::mount('user.edit-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1014012733-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:user.edit-user>
    <div class="py-4">

        

        <!-- Dialog (full screen) -->




        <?php if(session()->has('message')): ?>
        <div class="block px-4 py-2 text-white bg-opacity-50 bg-success rounded-xl">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        
        <div class="flex flex-row items-center justify-between">
            <div>
                <select name="paginate" id="paginate" wire:model="paginate"
                    class="block w-full text-sm capitalize border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="15">15</option>
                </select>
            </div>
            <div class="md:w-3/12">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="w-full overflow-x-auto">
            <table class="min-w-full mt-2 divide-y divide-gray-200 table-auto">
                <thead class="bg-gray-50">
                    <tr class="">
                        <th scope="col"
                            class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                            #
                        </th>
                        <th scope="col"
                            class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                            Nama
                        </th>
                        <th scope="col"
                            class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                            No Telepon
                        </th>
                        <th scope="col"
                            class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                            Alamat
                        </th>
                        
                        <th scope="col"
                            class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase ">
                            <span>Edit</span>
                            <span>Hapus</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-3 text-sm text-gray-500 md:px-6 whitespace-nowrap">
                            <?php echo e($key + 1); ?>

                        </td>
                        <td class="px-2 py-4 md:px-6">
                            <div class="flex items-center gap-x-2">
                                <div class="w-14 h-14 ">
                                    <img class="object-cover rounded-lg"
                                        src="<?php echo e($user->anggota->foto  !== '' ? asset('storage/'.$user->anggota->foto) : asset('images/default-user.png')); ?>"
                                        alt="Foto User">
                                </div>
                                <div class="flex flex-col gap-y-0">
                                    <span class="font-bold text-blue-500 uppercase"><?php echo e($user->anggota()->first()->nama); ?></span>
                                    <span class="font-bold"><?php echo e($user->email); ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($user->anggota->no_telpon); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($user->anggota->alamat); ?>

                        </td>
                        
                        <td class="px-2 md:px-6">
                            <div class="flex flex-row items-center space-x-4">
                                <button @click="modalEdit = true" wire:click.prevent="$emit('getUser', <?php echo e($user->id); ?>)"
                                    type="button" class="text-sm btn-secondary">edit</button>
                                <button wire:click="delete(<?php echo e($user->id); ?>)" type="button"
                                    class="text-sm btn-danger">hapus</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- More people... -->
                </tbody>
            </table>
        </div>
        <?php echo e($users->links()); ?>


    </div>
</div><?php /**PATH C:\applications\simpkk\resources\views/livewire/user-index.blade.php ENDPATH**/ ?>
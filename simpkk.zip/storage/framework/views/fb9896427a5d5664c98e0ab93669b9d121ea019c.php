<div class="py-12 md:px-8">
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dasawisma')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if(session()->has('message')): ?>
        <div class="block px-4 py-2 my-2 text-white bg-opacity-50 bg-success rounded-xl">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="px-4 py-2 mt-4 bg-white divide-y-2 divide-gray-200 rounded-lg shadow-lg">
        <div class="flex flex-row py-2 space-x-4">
            <a href="<?php echo e(route('dasawisma.create')); ?>" class="text-sm btn-primary">Tambah Dasawisma</a>
        </div>
        <div>
            <div class="flex flex-row items-center justify-between">
                <div class="py-2">
                    <select name="paginate" id="paginate" wire:model="paginate"
                        class="block w-full text-sm capitalize border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                    </select>
                </div>
                <div class="md:w-3/12">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="w-full overflow-x-auto">
                <table class="min-w-full mt-2 divide-y divide-gray-200 table-auto">
                    <thead class="bg-gray-50">
                        <tr class="">
                            <th scope="col"
                                class="w-1/12 px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                #
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Nama Anggota Dasawisma
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Dusun
                            </th>

                            <th scope="col"
                                class="w-3/12 px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase ">
                                <span class="sr-only">Detail</span>
                                <span class="sr-only">Edit</span>
                                <span class="sr-only">Hapus</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if($dasawisma->count() != 0): ?>
                            <?php $__currentLoopData = $dasawisma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-3 text-sm text-gray-500 md:px-6 whitespace-nowrap">
                                        <?php echo e($key + 1); ?>

                                    </td>
                                    <td class="px-2 py-4 md:px-6">
                                        <?php echo e($row->filterNama()->Nama_Lengkap); ?>

                                    </td>
                                    <td class="px-2 md:px-6">
                                        <?php echo e($row->filterNama()->dusun); ?>

                                    </td>
                                    <td class="px-2 md:px-6">
                                        <div class="flex flex-row items-center space-x-4">
                                            <a href="<?php echo e(route('dasawisma.detail', $row->id)); ?>"
                                                class="text-sm btn-warning">Detail</a>
                                            <a href="<?php echo e(route('dasawisma.edit', $row->id)); ?>"
                                                class="text-sm btn-secondary">Edit</a>
                                            <button wire:click="delete(<?php echo e($row->id); ?>)" type="button"
                                                class="text-sm btn-danger">hapus</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="font-medium text-center text-danger">Data tidak ditemukan..</td>
                            </tr>
                        <?php endif; ?>


                        <!-- More people... -->
                    </tbody>
                </table>


            </div>
            <?php echo e($dasawisma->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\applications\simpkk\resources\views/livewire/dasawisma/index.blade.php ENDPATH**/ ?>
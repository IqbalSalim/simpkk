<div class="py-12 md:px-8">
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Program Kerja')); ?>

        </h2>
     <?php $__env->endSlot(); ?>



    <div x-cloak class="px-4 py-2 bg-white rounded-lg shadow-lg" x-data="{ modal: false, modalEdit: false }"
        x-on:close-modal.window="modal = false" x-on:close-modal-edit.window="modalEdit = false">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proker.create-proker', [])->html();
} elseif ($_instance->childHasBeenRendered('l1540154444-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1540154444-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1540154444-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1540154444-0');
} else {
    $response = \Livewire\Livewire::mount('proker.create-proker', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1540154444-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:proker.create-proker>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proker.edit-proker', [])->html();
} elseif ($_instance->childHasBeenRendered('l1540154444-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1540154444-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1540154444-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1540154444-1');
} else {
    $response = \Livewire\Livewire::mount('proker.edit-proker', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1540154444-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:proker.edit-proker>

        <div
            class="flex flex-row items-center justify-between py-2 font-semibold text-gray-700 border-b-2 border-gray-300">
            <div>
                <h2>Daftar Program Kerja</h2>
            </div>
            <div>
                <button class="btn-primary" @click="modal = true">Tambah Program Kerja</button>

            </div>
        </div>
        <div class="py-4">
            



            <!-- Dialog (full screen) -->




            <?php if(session()->has('message')): ?>
            <div class="block px-4 py-2 my-2 text-white bg-opacity-50 bg-success rounded-xl">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
            <div class="flex flex-row items-center justify-between">
                <div>
                    <select name="paginate" id="paginate" wire:model="paginate"
                        class="block w-full text-sm capitalize border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                    </select>
                </div>
                <div class="md:w-3/12">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'search','id' => 'search','class' => 'block w-full text-sm','placeholder' => 'Search...','type' => 'text','name' => 'search','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="w-full overflow-x-auto md:overflow-hidden">
                <table class="min-w-full mt-2 divide-y divide-gray-200 table-auto">
                    <thead class="bg-gray-50">
                        <tr class="">
                            <th scope="col"
                                class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                #
                            </th>
                            <th scope="col"
                                class="w-2/12 px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Program Kegiatan
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Tujuan
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Sasaran
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Penanggungjawab
                            </th>
                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase md:px-6">
                                Program Pokok
                            </th>

                            <th scope="col"
                                class="px-2 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase ">
                                <span class="sr-only">Edit</span>
                                <span class="sr-only">Hapus</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $prokers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $proker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-sm">
                            <td class="px-4 py-3 text-sm text-gray-500 md:px-6 whitespace-nowrap">
                                <?php echo e($key + 1); ?>

                            </td>
                            <td class="px-2 py-4 md:px-6">
                                <?php echo e($proker->nama); ?>

                            </td>
                            <td class="px-2 md:px-6">
                                <?php echo e($proker->tujuan); ?>

                            </td>
                            <td class="px-2 md:px-6">
                                <?php echo e($proker->sasaran); ?>

                            </td>
                            <td class="px-2 md:px-6">
                                <?php echo e($proker->pj); ?>

                            </td>
                            <td class="px-2 md:px-6">
                                <?php echo e($proker->program_pokok); ?>

                            </td>
                            <td class="px-2 md:px-6">
                                <div class="flex flex-row items-center space-x-4">
                                    <button @click="modalEdit = true"
                                        wire:click.prevent="$emit('getProker', <?php echo e($proker->id); ?>)" type="button"
                                        class="text-sm btn-secondary">edit</button>
                                    <button wire:click="delete(<?php echo e($proker->id); ?>)" type="button"
                                        class="text-sm btn-danger">hapus</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- More people... -->
                    </tbody>
                </table>
            </div>
            <?php echo e($prokers->links()); ?>


        </div>

    </div>
</div><?php /**PATH C:\applications\simpkk\resources\views/livewire/proker-index.blade.php ENDPATH**/ ?>
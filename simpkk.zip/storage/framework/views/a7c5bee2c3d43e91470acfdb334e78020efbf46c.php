<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Kegiatan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 md:px-8">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('kegiatan-index', [])->html();
} elseif ($_instance->childHasBeenRendered('PK7Zd2a')) {
    $componentId = $_instance->getRenderedChildComponentId('PK7Zd2a');
    $componentTag = $_instance->getRenderedChildComponentTagName('PK7Zd2a');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PK7Zd2a');
} else {
    $response = \Livewire\Livewire::mount('kegiatan-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('PK7Zd2a', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:kegiatan-index>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\applications\simpkk\resources\views/kegiatan.blade.php ENDPATH**/ ?>
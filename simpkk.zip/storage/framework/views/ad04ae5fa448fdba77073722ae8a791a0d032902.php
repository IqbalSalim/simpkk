<div class="px-4 py-12 md:px-12">
    <div class="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
        
        <div class="md:w-8/12">
            <div class="bg-white rounded-lg shadow-lg ">
                <div class="flex flex-col px-4 py-2">
                    <h2 class="font-semibold"><?php echo e($warta->judul); ?></h2>
                    <span class="text-sm"><?php echo e($warta->created_at->isoFormat('D MMMM Y, HH:mm:ss')); ?></span>
                </div>
                <img class="object-cover w-full h-80" src="<?php echo e(asset('storage/' . $warta->gambar)); ?>" alt="gambar">
                <div class="flex flex-col px-4 py-2 space-y-2">
                    <?php echo e($warta->isi); ?>

                </div>
            </div>
        </div>
        
        
        <div class="md:w-4/12">
            <div class="flex-col px-2 py-2 space-y-2 bg-white rounded-lg shadow-lg">
                <div class="text-center">
                    <h3 class="font-semibold text-primary">Populer</h3>
                </div>
                <div class="flex flex-col border-gray-100 item-center">
                    <?php if(isset($warta_populer)): ?>
                        <?php $__currentLoopData = $warta_populer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('warta.detail', $ws->id)); ?>"
                                class="flex flex-row py-1 border-t-2 border-gray-50">
                                <img src="<?php echo e(asset('storage/' . $ws->gambar)); ?>" alt="gambar"
                                    class="object-cover w-4/12 h-20 rounded-md">
                                <div class="px-2 hover:text-primary">
                                    <p class="text-sm font-semibold line-clamp-2"><?php echo e($ws->judul); ?></p>
                                    <span class="text-xs text-default"><?php echo e($ws->created_at->diffForHumans()); ?></span>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php /**PATH C:\applications\simpkk\resources\views/livewire/detail-warta.blade.php ENDPATH**/ ?>
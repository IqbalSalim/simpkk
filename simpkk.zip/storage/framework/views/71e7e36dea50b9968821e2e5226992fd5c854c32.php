<div class="py-12 md:px-8">
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Struktur Organisasi')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if(session()->has('message')): ?>
    <div class="block px-4 py-2 text-white bg-opacity-50 bg-success rounded-xl">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
    <div class="px-4 py-2 bg-white rounded-lg shadow-lg">
        <div>
            <h2 class="font-semibold text-gray-700">Form Struktur Organisasi</h2>
        </div>
        <div class="py-4">
            <form wire:submit.prevent='update' novalidate>
                <div class="mt-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'struktur','value' => __('Upload File')]]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'struktur','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Upload File'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['wire:model' => 'struktur','id' => 'struktur','class' => 'block w-full mt-1 text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50','type' => 'file','name' => 'struktur','autofocus' => true]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'struktur','id' => 'struktur','class' => 'block w-full mt-1 text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50','type' => 'file','name' => 'struktur','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <span class="text-sm text-danger">
                        <?php $__errorArgs = ['struktur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>

                <!-- Preview what the editor is creating -->
                <div class="flex flex-row mt-4">
                    <button class="font-medium btn-primary btn-sm" wire:click.prevent='update'>Simpan</button>
                </div>

                <div class="flex flex-row items-center justify-center mt-4">
                    <div>
                        <img src="<?php echo e($status_gambar ? asset('storage/' . $gambar) : asset($gambar)); ?>"
                            alt="Gambar Struktur Organisasi">
                    </div>
                </div>
            </form>
        </div>
    </div>

</div><?php /**PATH C:\applications\simpkk\resources\views/livewire/struktur.blade.php ENDPATH**/ ?>
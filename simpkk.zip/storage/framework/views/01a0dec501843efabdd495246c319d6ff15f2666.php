<?php $attributes = $attributes->exceptProps(['active']); ?>
<?php foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$classes =
    $active ?? false
        ? 'block py-2 border-l-2  block text-white  px-4 focus:outline-none
        text-sm
         border-warning transition duration-150 ease-in-out'
        : 'block items-center px-4 block text-white  border-b-2 border-transparent text-sm py-2
        focus:outline-none  transition duration-150 ease-in-out';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\applications\simpkk\resources\views/components/responsive-nav-link.blade.php ENDPATH**/ ?>